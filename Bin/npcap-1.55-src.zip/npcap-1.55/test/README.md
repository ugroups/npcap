#Tests for Npcap.

Requirements:

* Npcap installed
* Nmap installed
* Some examples from the SDK

##SDK examples required

From `Examples-pcap`:

* iflist.exe
* pcap_filter.exe
* sendpack.exe
* readfile.exe

From `Examples-remote`:

* sendcap.exe
